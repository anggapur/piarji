<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gapok extends Model
{
    //
    protected $table = "gapok";
    protected $fillable = ["kdkelgapok","kdgapok","gapok"];
}
