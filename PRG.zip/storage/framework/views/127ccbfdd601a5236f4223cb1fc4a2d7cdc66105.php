<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-12">         
              <div class="alert alert-success" style="display: none;">
                  Berhasil Simpan Data
              </div>          
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <div class="box box-info">
            <!-- <form method="POST" action="<?php echo e(route('absensi.store')); ?>">   -->
              <?php echo e(csrf_field()); ?>

            <div class="box-header">              
              <h3 class="box-title">Form Absensi</h3>                            
            </div>
            <div class="box-body">    
              <form class="form-inline" id="formBulanTahun">
                <div class="form-group">
                  <label>Bulan</label>
                  <select class="form-control" name="bulan">
                    <option value="1">Januari</option>
                    <option value="2">February</option>
                    <option value="3">Maret</option>
                    <option value="4">April</option>
                    <option value="5">Mei</option>
                    <option value="6">Juni</option>
                    <option value="7">Juli</option>
                    <option value="8">Agustus</option>
                    <option value="9">September</option>
                    <option value="10">Oktober</option>
                    <option value="11">November</option>
                    <option value="12">Desember</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Tahun</label>
                  <select class="form-control" name="tahun">
                    <?php for($i = $tahunTerkecil; $i <= date('Y')+1 ; $i++): ?>
                      <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                    <?php endfor; ?>
                  </select>
                </div>
                <div class="form-group">
                  <input type="submit" name="submitBulanTahun" value="Pilih" class="btn btn-success" id="btnPilih">
                </div>
              </form>
              <hr>
                <form style="display: none;" id="formAbsensi">
                  <table id="example" class="display table table-bordered table-striped" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>NIP</th>
                            <th>Nama</th>
                             <?php $__currentLoopData = $dataAturanAbsensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                              <th class="col-xs-1 absensiColumn no-sort" style="width:10% !important"><?php echo e($val->nama); ?></th>                  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>                   
                    <tbody>
                      <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td><?php echo e($value->nip); ?></td>                           
                            <td><?php echo e($value->nama); ?></td>     
                            <td class="inputColumn"><input type="number" name="absensi1" value="0" data="<?php echo e($value->nip); ?>" class="form-control" style="width:100px;" required /></td>                             
                            <td class="inputColumn"><input type="number" name="absensi2" value="0" data="<?php echo e($value->nip); ?>" class="form-control" style="width:100px;" required /></td>                             
                            <td class="inputColumn"><input type="number" name="absensi3" value="0" data="<?php echo e($value->nip); ?>" class="form-control" style="width:100px;" required /></td>                             
                            <td class="inputColumn"><input type="number" name="absensi4" value="0" data="<?php echo e($value->nip); ?>" class="form-control" style="width:100px;" required /></td>                             
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                    </tbody>
                  </table>                
                  <button id="get-result" class="btn btn-success">Simpan</button><br />
                  <textarea id="result-serialized" style="width: 200px; height: 100px;display: none;" class="hides"></textarea>
                  <textarea id="result-json" style="width: 200px; height: 100px;display: none;" class="hides"></textarea>  
                </form>
               
            </div>   
          </div>
          <!-- end box info -->
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
    
   <script type="text/javascript">
     $(function() {
      //deklarasi var
      json_obj = { 
        "bulan" : null,
        "tahun" : null,
        "absensi" : [],                
      };                 

        //form bulan tahun
        $('#formBulanTahun').submit(function(e){
          bulan = $(this).find("select[name='bulan']").val();
          tahun = $(this).find("select[name='tahun']").val();
          
          $.ajax({
                type: "POST",                  
                url: "<?php echo e(route('pilihBulanTahun')); ?>",
                data: 
                { 
                  "_token": "<?php echo e(csrf_token()); ?>",
                  "bulan" : bulan,
                  "tahun" : tahun,
                },
                success: function(data) {
                    console.log(data);
                    if(data.status == "success")
                    {                  
                      json_obj.bulan = bulan;    
                      json_obj.tahun = tahun;  
                      if(data.dataAbsensi !== null)  
                      {
                        arr = $();
                        for (var i = 0; i < t.rows()[0].length; i++) { 
                            arr = arr.add(t.row(i).node())
                        }
                        console.log(data.dataAbsensi);
                        $.each(data.dataAbsensi, function(k, v) {                          
                          arr.find('input[name="absensi1"][data="'+v.nip+'"]').val(v.absensi1);
                          arr.find('input[name="absensi2"][data="'+v.nip+'"]').val(v.absensi2);
                          arr.find('input[name="absensi3"][data="'+v.nip+'"]').val(v.absensi3);
                          arr.find('input[name="absensi4"][data="'+v.nip+'"]').val(v.absensi4);
                        });
                        
                      }                      
                      //
                      $('#formBulanTahun').find('select,input').attr('disabled','disabled');
                      $('#formAbsensi').fadeIn('slow');
                    }
                }
            });
          e.preventDefault();
        });

        //send data
        t = $('#example').DataTable( {
        "columnDefs": [ {
          "targets": 'no-sort',
          "orderable": false,
           "searchable": false,
            } ]
        } );
        $('#get-result').click(function(e) {
            e.preventDefault();
            ar = $()
            for (var i = 0; i < t.rows()[0].length; i++) { 
                ar = ar.add(t.row(i).node())
            }
            $('#result-serialized').val(ar.find('select,input,textarea').serialize());
               
            absensi1 = [];
            absensi2 = [];
            absensi3 = [];
            absensi4 = [];         
            ar.find('input').each(function(i, el) {    
              if($(el).attr('name') == "absensi1") 
              {
                  b = {
                    "id" : $(el).attr('data'),
                    "nilai" : $(el).val(),
                  };           
                  absensi1.push(b);
              }
              if($(el).attr('name') == "absensi2") 
              {
                  b = {
                    "id" : $(el).attr('data'),
                    "nilai" : $(el).val(),
                  };           
                  absensi2.push(b);
              }
              if($(el).attr('name') == "absensi3") 
              {
                  b = {
                    "id" : $(el).attr('data'),
                    "nilai" : $(el).val(),
                  };           
                  absensi3.push(b);
              }
              if($(el).attr('name') == "absensi4") 
              {
                  b = {
                    "id" : $(el).attr('data'),
                    "nilai" : $(el).val(),
                  };           
                  absensi4.push(b);
              }

            });
            json_obj.absensi[1] = absensi1;
            json_obj.absensi[2] = absensi2;
            json_obj.absensi[3] = absensi3;
            json_obj.absensi[4] = absensi4;
            $('#result-json').val(JSON.stringify(json_obj));

            //Kirim data melalui ajax
            $.ajax({
                type: "POST",                  
                url: "<?php echo e(route('absensi.store')); ?>",
                data: 
                { 
                  "_token": "<?php echo e(csrf_token()); ?>",
                  "datas" : json_obj,
                },
                success: function(data) {
                    if(data.status == "success")
                    {
                      $("html,body").scrollTop($("body").scrollTop() + 0);
                      $('.alert.alert-success').slideDown(200);
                      setTimeout(function(){ 
                         $('.alert.alert-success').fadeOut(500);
                        }, 4000);
                      
                    }
                }
            });
            //unset data
            absensi1 = null;
            absensi2 = null;
            absensi3 = null;
            absensi4 = null;
        });
    });
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>