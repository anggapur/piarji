<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-12">   
          <?php if(session('status')): ?>      
              <div class="alert alert-<?php echo e(session('status')); ?>">
                  <?php echo e(session('message')); ?>

              </div>         
          <?php endif; ?> 
           <div class="alert alert-success" id="alertDynamic" style="display: none">
                  
              </div>   
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <div class="box box-info noprint" >
            <!-- <form method="POST" action="<?php echo e(route('absensi.store')); ?>">   -->
              <?php echo e(csrf_field()); ?>

            <div class="box-header">              
              <h3 class="box-title">TTD Laporan C1 Polri & C2 PNS</h3>                            
            </div>
            <div class="box-body">   
            <div class="row"> 
              <form method="POST" action="<?php echo e(url('tandaTanganSetting/saveData')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <?php if($dataTTD->count() !== 0): ?>
                <div class="col-md-4">    
                  <h4>Tanda Tangan 1</h4>          
                  <div class="form-group">    
                    <label>Jabatan</label>
                    <input type="text" name="data[1][1][nilai1]" class="form-control" placeholder="Jabatan" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','1')->nilai1); ?>" required>
                  </div>
                  <div class="form-group">    
                    <label>Nama</label>
                    <input type="text" name="data[1][1][nilai2]" class="form-control" placeholder="Nama" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','1')->nilai2); ?>" required>
                  </div>
                  <div class="form-group">    
                    <label>Pangkat</label>
                    <input type="text" name="data[1][1][nilai3]" class="form-control" placeholder="Pangkat" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','1')->nilai3); ?>" required>
                  </div>
                  <div class="form-group">
                    <label>TTD</label>
                    <input type="file" name="image1" class="form-control">
                    <div class="wrapTTD">
                      <?php if(collect($dataTTD)->firstWhere('bagian','1')->image != ""): ?>
                      <span><i class="fa fa-trash deleteImage" data-id="<?php echo e(collect($dataTTD)->firstWhere('bagian','1')->id); ?>"></i></span>
                      
                      <img src="<?php echo e(url('public/images').'/'.collect($dataTTD)->firstWhere('bagian','1')->image); ?>" class="img-responsive" alt="Tidak Ada Gambar" data-id="<?php echo e(collect($dataTTD)->firstWhere('bagian','1')->id); ?>">
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <h4>Tanda Tangan 2</h4>   
                  <div class="form-group">    
                    <label>Mengetahui</label>
                    <input type="text" name="data[1][2][nilai4]" class="form-control" placeholder="Mengetahui" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','2')->nilai4); ?>" required>
                  </div>                     
                  <div class="form-group">    
                    <label>Jabatan</label>
                    <input type="text" name="data[1][2][nilai1]" class="form-control" placeholder="Jabatan" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','2')->nilai1); ?>" required>
                  </div>
                  <div class="form-group">    
                    <label>Nama</label>
                    <input type="text" name="data[1][2][nilai2]" class="form-control" placeholder="Nama" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','2')->nilai2); ?>" required>
                  </div>
                  <div class="form-group">    
                    <label>Pangkat</label>
                    <input type="text" name="data[1][2][nilai3]" class="form-control" placeholder="Pangkat" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','2')->nilai3); ?>" required>
                  </div>
                   <div class="form-group">
                    <label>TTD</label>
                    <input type="file" name="image2" class="form-control">
                    <div class="wrapTTD">
                      <?php if(collect($dataTTD)->firstWhere('bagian','2')->image != ""): ?>
                      <span><i class="fa fa-trash deleteImage" data-id="<?php echo e(collect($dataTTD)->firstWhere('bagian','2')->id); ?>"></i></span>
                      
                       <img src="<?php echo e(url('public/images').'/'.collect($dataTTD)->firstWhere('bagian','2')->image); ?>" class="img-responsive" alt="Tidak Ada Gambar" data-id="<?php echo e(collect($dataTTD)->firstWhere('bagian','2')->id); ?>">
                       <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">     
                  <h4>Tanda Tangan 3</h4> 
                  <div class="form-group">    
                    <label>Waktu</label>
                    <input type="text" name="data[1][3][nilai4]" class="form-control" placeholder="Waktu" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','3')->nilai4); ?>" required>
                  </div>                     
                  <div class="form-group">    
                    <label>Jabatan</label>
                    <input type="text" name="data[1][3][nilai1]" class="form-control" placeholder="Jabatan" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','3')->nilai1); ?>" required>
                  </div>
                  <div class="form-group">    
                    <label>Nama</label>
                    <input type="text" name="data[1][3][nilai2]" class="form-control" placeholder="Nama" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','3')->nilai2); ?>" required>
                  </div>
                  <div class="form-group">    
                    <label>Pangkat</label>
                    <input type="text" name="data[1][3][nilai3]" class="form-control" placeholder="Pangkat" value="<?php echo e(collect($dataTTD)->firstWhere('bagian','3')->nilai3); ?>" required>
                  </div>
                   <div class="form-group">
                    <label>TTD</label>
                    <input type="file" name="image3" class="form-control">
                      <div class="wrapTTD">
                        <?php if(collect($dataTTD)->firstWhere('bagian','3')->image != ""): ?>
                        <span><i class="fa fa-trash deleteImage" data-id="<?php echo e(collect($dataTTD)->firstWhere('bagian','3')->id); ?>"></i></span>
                        
                       <img src="<?php echo e(url('public/images').'/'.collect($dataTTD)->firstWhere('bagian','3')->image); ?>" class="img-responsive" alt="Tidak Ada Gambar" data-id="<?php echo e(collect($dataTTD)->firstWhere('bagian','3')->id); ?>">
                       <?php endif; ?>
                      </div>
                  </div>
                </div>
                <?php else: ?>
                <div class="col-md-4">    
                  <h4>Tanda Tangan 1</h4>          
                  <div class="form-group">    
                    <label>Jabatan</label>
                    <input type="text" name="data[1][1][nilai1]" class="form-control" placeholder="Jabatan" value="" required>
                  </div>
                  <div class="form-group">    
                    <label>Nama</label>
                    <input type="text" name="data[1][1][nilai2]" class="form-control" placeholder="Nama" value="" required>
                  </div>
                  <div class="form-group">    
                    <label>Pangkat</label>
                    <input type="text" name="data[1][1][nilai3]" class="form-control" placeholder="Pangkat" value="" required>
                  </div>
                  <div class="form-group">
                    <label>TTD</label>
                    <input type="file" name="image1" class="form-control">                    
                  </div>
                </div>
                <div class="col-md-4">
                  <h4>Tanda Tangan 2</h4> 
                  <div class="form-group">    
                    <label>Mengetahui</label>
                    <input type="text" name="data[1][2][nilai4]" class="form-control" placeholder="Jabatan" value="" required>
                  </div>                       
                  <div class="form-group">    
                    <label>Jabatan</label>
                    <input type="text" name="data[1][2][nilai1]" class="form-control" placeholder="Jabatan" value="" required>
                  </div>
                  <div class="form-group">    
                    <label>Nama</label>
                    <input type="text" name="data[1][2][nilai2]" class="form-control" placeholder="Nama" value="" required>
                  </div>
                  <div class="form-group">    
                    <label>Pangkat</label>
                    <input type="text" name="data[1][2][nilai3]" class="form-control" placeholder="Pangkat" value="" required>
                  </div>
                  <div class="form-group">
                    <label>TTD</label>
                    <input type="file" name="image2" class="form-control">
                    
                  </div>
                </div>
                <div class="col-md-4">     
                  <h4>Tanda Tangan 3</h4> 
                   <div class="form-group">    
                    <label>Waktu</label>
                    <input type="text" name="data[1][3][nilai4]" class="form-control" placeholder="Waktu" value="" required>
                  </div>                  
                  <div class="form-group">    
                    <label>Jabatan</label>
                    <input type="text" name="data[1][3][nilai1]" class="form-control" placeholder="Jabatan" value="" required>
                  </div>
                  <div class="form-group">    
                    <label>Nama</label>
                    <input type="text" name="data[1][3][nilai2]" class="form-control" placeholder="Nama" value="" required>
                  </div>
                  <div class="form-group">    
                    <label>Pangkat</label>
                    <input type="text" name="data[1][3][nilai3]" class="form-control" placeholder="Pangkat" value="" required>
                  </div>
                  <div class="form-group">
                    <label>TTD</label>
                    <input type="file" name="image3" class="form-control">
                    
                  </div>
                </div>
                <?php endif; ?>
                <div class="col-md-12">
                  <input type="submit" name="submitForm" class="btn btn-success" value="Simpan">
                </div>
              </form>
            </div>
            </div>
          </div>
           
          <!-- end box info -->
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
  
   <script type="text/javascript">     
    $(document).ready(function(){
      $('.deleteImage').click(function(){
        //alert($(this).attr('data-id'));
        idImage = $(this).attr('data-id');
        $.ajax({
                type: "POST",                  
                url: "<?php echo e(route('deleteImageTTD')); ?>",
                data: 
                { 
                  "_token": "<?php echo e(csrf_token()); ?>",
                  "id" : idImage,
                },
                success: function(data) {
                  
                    if(data.status == "success")
                    {
                      // alert('dihapus');
                      $('#alertDynamic').html('Berhasil Hapus Gambar');
                        $('#alertDynamic').fadeIn('slow');
                      setTimeout(function(){
                        $('#alertDynamic').fadeOut('slow');
                      },3000);
                        $('img[data-id="'+idImage+'"]').fadeOut();
                    }
                }
            });
        $(this).fadeOut();
      });
    });
   </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>