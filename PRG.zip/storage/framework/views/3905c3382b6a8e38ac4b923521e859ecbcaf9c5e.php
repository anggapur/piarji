<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-6">
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <div class="box box-info">
            <div class="box-header">              
              <h3 class="box-title">Form Edit User</h3>              
              <!-- /. tools -->
            </div>
            <div class="box-body">
              <form action="<?php echo e(route('settingUser.update',$dataUser->id)); ?>" method="POST">
                 <?php echo method_field('PUT'); ?>
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label>Username</label>
                  <input type="text" class="form-control" name="name" placeholder="Username" value="<?php echo e($dataUser->name); ?>" required>
                </div>
                <div class="form-group">
                  <label>Email</label>
                  <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e($dataUser->email); ?>" required>
                </div>
                <div class="form-group">
                  <label>Password</label>
                  <input type="password" class="form-control" name="password" placeholder="Password" required>
                </div>
                <div class="form-group">
                  <label>Confirmation Password</label>
                  <input type="password" class="form-control" name="conf_password" placeholder="Confirm Password" required>
                </div>
                <div>
                  <label>Kode Satker</label>
                  <select class="js-example-basic-single form-control" name="kd_satker" required>                    
                    <?php $__currentLoopData = $dataSatker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($val->id); ?>" <?php echo e(($val->id == $dataUser->kd_satker) ? "selected" : ""); ?>><?php echo e($val->kd_satker." - ".$val->nm_satker); ?></option>                                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>                 
                </div>              
            </div>
            <div class="box-footer clearfix">
              <button type="submit" class="pull-right btn btn-success" id="sendEmail">Update User
                <i class="fa fa-arrow-circle-right"></i></button>
            </div>
          </div>
          </form>
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>