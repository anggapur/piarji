<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-6">
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <?php if(session('status')): ?>
              <div class="alert alert-<?php echo e(session('status')); ?>">
                  <?php echo session('message'); ?>

              </div>
          <?php endif; ?>
          <div class="box box-info">
            <div class="box-header">              
              <h3 class="box-title">Form Update Kebijakan Absensi</h3>              
              <!-- /. tools -->
            </div>
            <div class="box-body">
              <div class="form-group">
                <label>Keterangan</label>
                <p>
                  G = Gaji<br>
                  H = Hari<br>
                </p>
              </div>
              <hr>
              <form action="<?php echo e(route('kebijakanAbsensi.update',Auth::user()->id)); ?>" method="POST">
                 <?php echo method_field('PUT'); ?>
                <?php echo e(csrf_field()); ?>

                <?php $__currentLoopData = $dataKebijakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                  <label>Nama Rumus</label>
                  <textarea class="form-control"  name="nama[<?php echo e($val->id); ?>]" rows="3" required> <?php echo $val->nama; ?> </textarea>
                  <label>Rumus</label>
                  <input type="text" class="form-control"  name="rumus[<?php echo e($val->id); ?>]" value="<?php echo e($val->rumus); ?>" required>
                </div>     
                <hr>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                              
            </div>
            <div class="box-footer clearfix">
              <button type="submit" class="pull-right btn btn-success" id="updateKebijakan">Update Kebijakan Absensi
                <i class="fa fa-arrow-circle-right"></i></button>
            </div>
          </div>
          </form>
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
    <!-- /.content -->
    <script type="text/javascript">
      $(".form-control").on({
        keydown: function(e) {
          if (e.which === 32)
            return false;
        },
        change: function() {
          this.value = this.value.replace(/\s/g, "");
        }
      });
    </script>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>