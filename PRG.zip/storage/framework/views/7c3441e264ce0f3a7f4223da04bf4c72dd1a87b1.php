<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-12">         
              <div class="alert alert-success" style="display: none;">
                  Berhasil Simpan Data
              </div>          
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <div class="box box-info">
            <!-- <form method="POST" action="<?php echo e(route('absensi.store')); ?>">   -->
              <?php echo e(csrf_field()); ?>

            <div class="box-header">              
              <h3 class="box-title">List Backup File</h3>                            
            </div>
            <div class="box-body">    
              <table id="example1" class="display table table-bordered table-striped" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <td>No</td>
                    <td>Tanggal</td>
                    <td>Action</td>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      <?php echo e($loop->iteration); ?>

                    </td>
                    <td>
                      <?php
                        $file = substr($value,26,19);
                        $date = substr($file,0,10);
                        $date = str_replace('-','/',$date);
                        $time = str_replace('-',':',substr($file,11,5));
                      ?>
                      <b><?php echo e(Carbon\Carbon::parse($date)->format('d F Y')); ?></b> <span style="padding-left: 10px;"><?php echo e($time); ?></span>
                    </td>
                    <td>
                      <a href="<?php echo e(asset($value)); ?>" class="btn btn-success btn-xs">Download</a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>   
          </div>
          <!-- end box info -->
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>