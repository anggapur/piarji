<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-6">
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <?php if(session('status')): ?>
              <div class="alert alert-<?php echo e(session('status')); ?>">
                  <?php echo session('message'); ?>

              </div>
          <?php endif; ?>
          <div class="box box-info">
            <div class="box-header">              
              <h3 class="box-title">Form Import Data Pegawai</h3>              
              <!-- /. tools -->
            </div>
            <div class="box-body">
              <div class="col-md-12">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" method="POST" action="<?php echo e(url('pegawaiSetting/importDataPegawai')); ?>" >
                  <?php echo e(csrf_field()); ?>

                     <!--  <div class="form-group">                        
                      <a href="<?php echo e(url('exportproduk')); ?>" class="btn btn-success">Export</a>                        
                      </div> -->
                      <div class="form-group">
                          <label for="file" >File</label>                        
                          <input id="file" type="file" class="form-control" name="file">                        
                      </div>
                      <div class="form-group">                         
                          <button type="submit" class="btn btn-primary">Import Data  Pegawai</button>                        
                      </div>
                </form>         
              </div>
            </div>           
          </div>          
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>