<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-6">
         <?php if(session('status')): ?>
              <div class="alert alert-success">
                  <?php echo session('message'); ?>

              </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <div class="box box-info">
            <div class="box-header">              
              <h3 class="box-title">Form Sinkronisasi Data</h3>                            
            </div>
            <div class="box-body">
              <form action="<?php echo e(url('sinkronisasiData')); ?>" method="POST">     
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label>Pilih Data Yang Disinkronisasi</label><br>
                  <input class="" type="checkbox" value="yes" name="dept">Data Departemen<br>
                  <input class="" type="checkbox" value="yes" name="lokasi">Data Lokasi<br>
                  <input class="" type="checkbox" value="yes" name="unit">Data Unit<br>
                  <input class="" type="checkbox" value="yes" name="pangkat">Data Pangkat<br>
                  <input class="" type="checkbox" value="yes" name="gapok">Data Gaji Pokok<br>
                  <input class="" type="checkbox" value="yes" name="pegawai">Data Pegawai<br>
                  <input class="" type="checkbox" value="yes" name="satker">Data Satker<br>
                </div>
                <div class="form-group">
                  <input type="submit" name="submit" value="Sinkronisasi" class="btn btn-success">
                </div>
            </div>           
          </div>
          <!-- end box info -->
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>