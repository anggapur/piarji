<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-6">
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <div class="box box-info">
            <div class="box-header">              
              <h3 class="box-title">Form Edit Pegawai</h3>              
              <!-- /. tools -->
            </div>
            <div class="box-body">              
              <form action="<?php echo e(route('dataPegawai.update',$dataPegawai->id)); ?>" method="POST">
                 <?php echo method_field('PUT'); ?>
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label>NIP/NRP</label>
                  <input type="text" class="form-control" name="nip" placeholder="NIP/NRP" value="<?php echo e($dataPegawai->nip); ?>" readonly>
                </div>
                <div class="form-group">
                  <label>Nama</label>
                  <input type="text" class="form-control" name="nama" placeholder="Nama" value="<?php echo e($dataPegawai->nama); ?>" required>
                </div>
                <div class="form-group">
                  <label>Kelas Jabatan</label>
                  <select class="form-control" name="kelas_jab" required>
                    <?php $__currentLoopData = $aturanTunkin->detailAturanTunkinDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($value->kelas_jabatan); ?>" <?php if($dataPegawai->kelas_jab == $value->kelas_jabatan): ?> selected <?php endif; ?> > <?php echo e($value->kelas_jabatan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Pangkat</label>
                    <input list="pangkat" name="kd_pangkat" class="form-control" placeholder="Pangkat" value="<?php echo e($dataPegawai->nm_pangkat2); ?>" required>
                    <datalist id="pangkat">
                      <?php $__currentLoopData = $pangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->nm_pangkat2); ?>">                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                </div>
                <div class="form-group">
                  <label>Jabatan</label>
                    <input list="jabatan" name="kd_jab" class="form-control" placeholder="Jabatan" value="<?php echo e($dataPegawai->nm_jabatan); ?>" required>
                    <datalist id="jabatan">
                      <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val->nm_jabatan); ?>">                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                </div>
                <div class="form-group">
                  <label>Jenis Kelamin</label><br>
                  <input type="radio" name="jenis_kelamin" value="L" <?php if($dataPegawai->jenis_kelamin == "L"): ?> checked <?php endif; ?>> Laki - Laki <br>
                  <input type="radio" name="jenis_kelamin" value="P" <?php if($dataPegawai->jenis_kelamin == "P"): ?> checked <?php endif; ?>> Perempuan <br>
                </div>
                <div class="form-group">
                  <label>Status</label><br>
                  <input type="radio" name="kawin" value="K" <?php if($dataPegawai->kawin == "K"): ?> checked <?php endif; ?>> Kawin <br>
                  <input type="radio" name="kawin" value="TK" <?php if($dataPegawai->kawin == "TK"): ?> checked <?php endif; ?>> Tidak Kawin <br>
                </div>
                <div class="form-group">        
                  <label>Tanggungan</label>
                  <input type="number" class="form-control" name="tanggungan" placeholder="Tanggungan" value="<?php echo e($dataPegawai->tanggungan); ?>" required>
                </div>
                <div class="form-group">        
                  <label>Gaji Pokok</label>
                  <input type="text" class="form-control money" name="gapok" placeholder="Gaji Pokok" value="<?php echo e(CH::currencyIndo($dataPegawai->gapok)); ?>" required>
                </div>
                <div class="form-group">        
                  <label>Tunjangan Struktural Fungsional</label>
                  <input type="text" class="form-control money" name="tunj_strukfung" placeholder="Tunjangan Struktural Fungsional" value="<?php echo e(CH::currencyIndo($dataPegawai->tunj_strukfung)); ?>" required>
                </div>
                <div class="form-group">        
                  <label>Tunjangan Lain - Lain</label>
                  <input type="text" class="form-control money" name="tunj_lain" placeholder="Tunjangan Lain - Lain" value="<?php echo e(CH::currencyIndo($dataPegawai->tunj_lain)); ?>" required>
                </div>
                <?php if(Auth::user()->level == "admin"): ?>
                <div class="form-group">
                  <label>Kode Satker</label>
                  <select class="js-example-basic-single form-control" name="kd_satker" required>                    
                    <?php $__currentLoopData = $dataSatker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($val->kd_satker); ?>" <?php echo e(($val->kd_satker == $dataPegawai->kd_satker) ? "selected" : ""); ?>><?php echo e($val->kd_satker." - ".$val->nm_satker); ?></option>                                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>                 
                </div>              
                <?php endif; ?>
            </div>
            <div class="box-footer clearfix">
              <button type="submit" class="pull-right btn btn-success" id="sendEmail">Update Pegawai
                <i class="fa fa-arrow-circle-right"></i></button>
            </div>
          </div>
          </form>
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
    <!-- /.content -->
    <script type="text/javascript">
      $(document).ready(function(){
        $('.money').maskNumber({integer: true,thousands: '.'});
      });
    </script>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>