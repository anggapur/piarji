<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-6">
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <div class="box box-info">
            <div class="box-header">              
              <h3 class="box-title">Form Edit Rekening Pegawai</h3>              
              <!-- /. tools -->
            </div>
            <div class="box-body">
              <form action="<?php echo e(route('settingRekening.update',$dataUser->id)); ?>" method="POST">
                 <?php echo method_field('PUT'); ?>
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label>NIP</label>
                  <input type="text" class="form-control" placeholder="Username" value="<?php echo e($dataUser->nip); ?>" disabled>
                </div>
                <div class="form-group">
                  <label>Nama</label>
                  <input type="text" class="form-control" placeholder="Username" value="<?php echo e($dataUser->nama); ?>" disabled>
                </div>
                <div class="form-group">
                  <label>No Rekening</label>
                  <input type="text" name="no_rekening" placeholder="No Rekening" class="form-control" value="<?php echo e($dataUser->no_rekening); ?>">
                </div>
            </div>
            <div class="box-footer clearfix">
              <button type="submit" class="pull-right btn btn-success" id="sendEmail">Update Pegawai
                <i class="fa fa-arrow-circle-right"></i></button>
            </div>
          </div>
          </form>
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>