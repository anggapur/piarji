<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-12 col-xs-6">
         <?php if(session('status')): ?>
              <div class="alert alert-<?php echo e(session('status')); ?>">
                  <?php echo session('message'); ?>

              </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </div>
          <?php endif; ?>
          <div class="box box-info">
            <div class="box-header">              
              <h3 class="box-title">Detail Aturan Tunkin</h3>                            
            </div>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped" style="width: 300px;">                
                <tbody>
                  <tr>
                    <td>Kode Aturan</td>
                    <td><b><?php echo e($datas->kd_aturan); ?></b></td>
                  </tr>      
                  <tr>
                    <td>Nama Aturan</td>
                    <td><b><?php echo e($datas->nama_aturan); ?></b></td>
                  </tr>
                  <tr>
                    <td>Status</td>
                    <td>
                      <?php if($datas->state == "1"): ?>
                          <span class="btn btn-xs btn-success">Aturan Aktif </span>
                        <?php else: ?>
                          <span class="btn btn-xs btn-danger">Aturan Tidak Aktif </span>  
                        <?php endif; ?>
                    </td>
                  </tr>  
                </tbody>                
              </table>
              <hr>
              <!-- Table 2  -->
              <table id="example1" class="table table-bordered table-striped" style="width: 300px;">                
                <thead>
                  <tr>
                    <th>Kelas Jabatan</th>
                    <th>Tunjangan</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $datas->detailAturanTunkinDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($val->kelas_jabatan); ?></td>
                    <td><?php echo e(CH::currencyIndo($val->tunjangan)); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>           
          </div>
          <!-- end box info -->
        </div>        
      </div>
      <!-- /.row -->
      
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>